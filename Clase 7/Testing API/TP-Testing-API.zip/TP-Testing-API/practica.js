const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const util = require('util');

const app = express();
const port = 3000;
app.use(express,json()); //permite el mapeo de la peticion json a object js
app.use(cors());//para filtrar url de clientes que se pueda peticionar a otros servidores

//conexion a base de datos
const conexion = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'biblioteca'
});

conexion.connect((error)=>{
    if(error){
        throw error;
    }
    console.log('conexión de base establecida');
});
const qy = util.promisify(conexion.query).bind(conexion);//permite el uso de asyn-await en la conexion de mysql

/**
 * GET para devolver todas las categorias
 * GET id para devolver uno solo
 * POST guardar una categoria nueva
 * PUT para modificar una categoria existente
 * DELETE para borrar una categoria existente
 * 
 * Ruta -> /categoria
 */

 /**
 * CATEGORIA
 */

  practica.get('/categoria', async (req, res) => {
    try {
        //armo la consulta
        const query = 'SELECT * FROM categoria';
        
        //ejecutamos la consulta(query)
        const respuesta = await qy(query);

        //el servidor devuelve la respuesta cuando pueda
        //al cliente como objeto json
        res.send({"respuesta": respuesta});
    }
    catch(e){
        //viene aca si hay algun error en la BD
        console.error(e.message);
    }
 });



 practica.get('/categoria/:id', async (req, res) => {
    try {
        const query = 'SELECT * FROM categoria WHERE id = ?';

        const respuesta = await qy(query, [req.params.id]);
        console.log(respuesta);

        // valido que la categoria solicitada exista previamente
        if (respuesta.length == 0) { 
            throw new Error('Categoria no encontrada');
        }

        res.send({"respuesta": respuesta});
    }
    catch(e){
        console.error(e.message);
        res.status(413).send(e.message);//mensaje de error personalizado
    }
 });



 practica.post('/categoria', async (req, res) => {
    try {
        // Valido envio del nombre de categoria
        if (!req.body.nombre) {
            throw new Error('Falta enviar el nombre');
        }

        // Verifico que no exista previamente esa categoria
        let query = 'SELECT id FROM categoria WHERE nombre = ?';

        let respuesta = await qy(query, [req.body.nombre.toLowerCase()]);

        if (respuesta.length > 0) { 
            throw new Error('Esa categoria ya existe');
        }

        // Guardo la nueva categoria
        query = 'INSERT INTO categoria (nombre) VALUE (?)';
        respuesta = await qy(query, [req.body.nombre.toLowerCase()]);
	    
        res.send({'respuesta': respuesta});//responde todo
    }   
    catch(e){
        res.status(413).send({"Error": e.message});
    }
 });



 practica.delete('/categoria/:id', async(req,res) => {
     try{
         let query = 'select * from libro where categoria_id = ?';
         let respuesta= await qy(query, [req.params.id]);

         if(respuesta.length >0 {
             throw new error ("esta categoria tiene libros asociados y no es posible borrar");
         }
         query = 'select * from categoria where id = ?';
         respuesta = await qy(query, [req.params.id]);
         //validamos que la categoria exista
         if (respuesta.length >0 {
            throw new error ("esa categoria no existe");
                 }
         query = 'delete from categoria where id = ? ';

         respuesta = await qy(query, [req.params.id]);

         res. send( 'se borro correctamente'); 
                }
        catch(e){
            res.status(413).send({"Error": e.message});
            res.status(413).send("Error Inesperado");
        }
 }); 
 

/**
 * PERSONA
 */
practica.post('/persona', async(req,res) => {
    try{
        //validamos el envio de los datos de la persona
        if(!req.body.nombre || !req.body.apellido || !req.body.alias ||!req.body.mail) {
            throw new Error('faltan datos');
        }
        // verifico que el mail no este registrado previamente
        let query = 'select id from persona where email = ?';

        let respuesta = await qy(query, [req.body.mail.toLowerCase()]);
        if (respuesta.length >0 {
            throw new error ("el mail ya se encuentra registrado");
        }
            //guardar
        query = "insert into persona (nombre,apellido,alias,email)values (?,?,?,?)";
        respuesta = await qy(query,[req.body.nombre, req.body.apellido, req.body.alias,req.body.email]);

                  res.send({'Registro insertado': {"Nombre" : req.body.nombre, "apellido": req.body.apellido,
                  "alias": req.body.alias, "email": req.body.email"}}); //responde todo
    }
     catch(e){
        res.status(413).send({"Error": e.message});
        }

        });

practica.get ('/persona', async(req, res)=> {
    try{
        const query = 'select from persona';
        const respuesta = await qy(query);
        res.send({"respuesta": respuesta});
            }
    catch(e){
        res.status(413).send({"Error": e.message});
    }
}) ;
practica.get('/persona/:id', async (req, res) => {
    try {
        const query = 'SELECT * FROM persona WHERE id = ?';

        const respuesta = await qy(query, [req.params.id]);
        

        // valido que la persona  solicitada exista previamente
        if (respuesta.length == 0) { 
            throw new Error('Persona  no encontrada');
        }

        res.send({"respuesta": respuesta});
    }
    catch(e){
       
        res.status(413).send(e.message);//mensaje de error personalizado
    }
 });

 practica.put('/persona/:id', async (req, res) =>{
     try{
         //validamos el envio de los datos de la persona
        if(!req.body.nombre || !req.body.apellido || !req.body.alias ||!req.body.mail) {
            throw new Error('faltan datos');
        }
        let query = ' select * from persona where email = ? and id <> ?';
        let respuesta= await qy(query, [req.body.email, req.params.id]);

        if (respuesta.length == 0) { 
            throw new Error('el mail de la persona  ya existe');
        }
        query = 'select * from persona where id = ?'; 
        respuesta= await qy(query, [req.params.id]);

        if (respuesta.length == 0) { 
            throw new Error('la persona no exista');
        }
        query = 'UPDATE persona SET nombre = ?, apellido= ? , alias= ?, email= ? WHERE id = ?';

        respuesta= await qy(query, [req.body.nombre.toLowerCase(), req.body.apellido.toLowerCase(), 
        req.body.alias.toLowerCase(),req.body.email.toLowerCase(), req.params.id] );
        
        res.send({"Registro actualizado": {"Nombre": req.body.nombre,'Apellido': req.body.apellido,
            "Alias": req.body.alias, "Email": req.body.email}}); 

     }
     catch(e){
         console.error(e.message);
         res.status(413).send(e.message);//mensaje de error personalizado 


     }
 }); 
practica.delete('/persona/:id', async(req,res) => {
    try{
        let query = 'select * from libro where persona_id = ?';
        let respuesta= await qy(query, [req.params.id]);

        if(respuesta.length >0 {
            throw new error ("esta persona no puede ser eliminada ya que posee libros asociados");
        }
        query = 'select * from persona where id = ?';
        respuesta = await qy(query, [req.params.id]);
        //validamos que la persona exista
        if (respuesta.length >0 {
           throw new error ("la persona indicada no existe");
                }
        query = 'delete from persona  where id = ? ';

        respuesta = await qy(query, [req.params.id]);

        res. send( 'se borro correctamente'); 
               }
       catch(e){
           res.status(413).send({"Error": e.message});
        
       }
    }); 
    /**
 * LIBRO
 */
practica.get('/libro', async (req, res) => {
        try {
            //armo la consulta
            const query = 'SELECT * FROM libro';
            
            //ejecutamos la consulta(query)
            const respuesta = await qy(query);
    
            //el servidor devuelve la respuesta cuando pueda
            //al cliente como objeto json
            res.send({"respuesta": respuesta});
        }
        catch(e){
            //viene aca si hay algun error en la BD
            console.error(e.message);
        }
     });
    
practica.get('/libro/:id', async (req, res) => {
        try {
            const query = 'SELECT * FROM categoria WHERE id = ?';
    
            const respuesta = await qy(query, [req.params.id]);
            console.log(respuesta);
    
            // valido que el libro  solicitado exista previamente
            if (respuesta.length == 0) { 
                throw new Error('libro  no encontrado');
            }
    
            res.send({"respuesta": respuesta});
        }
        catch(e){
            console.error(e.message);
            res.status(413).send(e.message);//mensaje de error personalizado
        }
     });

practica.post('/libro', async (req, res) => {
        try {
            // Valido envio de los datos del nombre
            if (!req.body.nombre || !req.body.categoria_id ) {
                throw new Error('Nombre y categoria son datos obligatorios');
            }
    
            // Verifico que el libro no este registrado previamente
            let query = 'SELECT id FROM libro  WHERE nombre = ?';
    
            let respuesta = await qy(query, [req.body.nombre.toLowerCase()]);
    
            if (respuesta.length > 0) { 
                throw new Error('Ese libro  ya existe');
            }
    
        

            query = 'SELECT * FROM libro where categoria_id=?';
            respuesta = await qy(query, [req.body.categoria_id]);

            //valido la categoria

            if (respuesta.length == 0) { 
                throw new Error('no existe la categoria indicada');
            }
            query= 'SELECT * FROM persona Where id = ?'; 
            respuesta = await qy(query, [req.body.persona_id]);
            console.log(respuesta);
            console.log(req.body.persona_id);

            // valido que la persona solicitada exista previamente
            if (respuesta.length==0 && req.body.persona_id != null){
                throw new console.error(('No existe la persona indicada');

            }

            //guardo el nuevo libro 
            query = "INSERT INTO libro (nombre, descripcion, categoria_id,persona_id)
            VALUES(?,?,?,?)"; 

            respuesta = await qy( query, [ req.body.nombre, req.body.descripcion,req.body.categoria_id,
                req.body.persona_id]); 

                res.send 



            
            res.send({'respuesta': respuesta});//responde todo
        }   
        catch(e){
            res.status(413).send({"Error": e.message});
        }
     });
    
    

//Servidor

app.listen(port, ()=>{
    console.log('Servidor escuchando en el puerto ', port);
});



